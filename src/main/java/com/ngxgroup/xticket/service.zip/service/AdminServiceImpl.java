package com.ngxgroup.xticket.service;

import com.ngxgroup.xticket.payload.XTicketPayload;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author bokon
 */
@Service
public class AdminServiceImpl implements AdminService{

    @Override
    public String authenticateUser(XTicketPayload requestPayload) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<String> fetchRoleGroup() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
